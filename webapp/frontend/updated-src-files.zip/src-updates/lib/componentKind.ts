// Ported 1:1 from the shop's Match Studio classifier
// (ms_classify_component_filename in the Elgin CMS backend) so a part
// groups the same way here as it does in every other shop tool.

export type ComponentKind =
  | "FULL ASSEMBLY"
  | "HOLDERS"
  | "ID POT"
  | "OD POT"
  | "TCP"
  | "BCP"
  | "ID HOLDER"
  | "OD HOLDER"
  | "HOLDER"
  | "ISO"
  | "OTHER";

export function classifyComponentFilename(fn: string): ComponentKind {
  const fnu = (fn || "").toUpperCase();
  const u = fnu.replace(/_/g, " ");
  const compact = u.replace(/[^A-Z0-9]/g, "");

  // Whole base + every part assembly (overlay the entire job).
  if (
    compact.includes("FULLASSEMBLY") ||
    compact.includes("WHOLEASSEMBLY") ||
    compact.includes("FULLBASE") ||
    compact.includes("WHOLEBASE")
  ) {
    return "FULL ASSEMBLY";
  }

  // Combined ID+OD holders.
  if (
    fnu.includes("_HOLDERS_") ||
    (compact.includes("HOLDERS") && !compact.includes("IDHOLDER") && !compact.includes("ODHOLDER"))
  ) {
    return "HOLDERS";
  }

  if (compact.includes("IDPOT") || (u.includes("POT") && u.includes("ID") && !u.includes("OD"))) {
    return "ID POT";
  }

  if (compact.includes("ODPOT") || (u.includes("POT") && (u.includes("OD") || u.includes("BOT")))) {
    return "OD POT";
  }

  if (u.includes("TCP") || compact.includes("TOPSMED") || u.includes("TOP CLAMP")) {
    return "TCP";
  }

  if (u.includes("BCP") || compact.includes("BOTTOMSMED") || u.includes("BOTTOM CLAMP") || u.includes("BOT CLAMP")) {
    return "BCP";
  }

  if (compact.includes("IDHOLDER") || (u.includes("HOLDER") && u.includes("ID") && !u.includes("OD"))) {
    return "ID HOLDER";
  }

  if (compact.includes("ODHOLDER") || (u.includes("HOLDER") && (u.includes("OD") || u.includes("BOT")))) {
    return "OD HOLDER";
  }

  if (u.includes("HOLDER")) return "HOLDER";
  if (u.includes("ISO")) return "ISO";

  return "OTHER";
}

// Quote line-item component names ("ID Holder", "OD Pot", "TCP", ...) run
// through the exact same rules, so a priced line and a 3D file land in the
// same bucket whenever they refer to the same physical part.
export const classifyQuoteComponentName = classifyComponentFilename;

// Display order for the Matching tab's part pills.
export const KIND_ORDER: ComponentKind[] = [
  "TCP",
  "BCP",
  "ID HOLDER",
  "OD HOLDER",
  "ID POT",
  "OD POT",
  "HOLDERS",
  "HOLDER",
  "FULL ASSEMBLY",
  "ISO",
  "OTHER",
];
