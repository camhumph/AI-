import type { BufferGeometry } from "three";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";

export interface GeomStats {
  sx: number;
  sy: number;
  sz: number; // bounding-box size
  bcx: number;
  bcy: number;
  bcz: number; // bounding-box center (world coords)
  comx: number;
  comy: number;
  comz: number; // center of mass, relative to bbox center
  vol: number; // volume, model units^3 (typically in^3)
  area: number;
  tris: number;
}

const EMPTY_STATS: GeomStats = {
  sx: 0, sy: 0, sz: 0, bcx: 0, bcy: 0, bcz: 0, comx: 0, comy: 0, comz: 0, vol: 0, area: 0, tris: 0,
};

export function emptyGeomStats(): GeomStats {
  return { ...EMPTY_STATS };
}

// Ported 1:1 from the shop's Match Studio overlay viewer (geomStats) so
// volume / center-of-mass numbers here always agree with the shop's other
// tools. Centroid uses the signed-tetrahedron method, so it is the true
// center of mass of the solid -- not just the bounding-box center.
export function computeGeomStats(geometry: BufferGeometry): GeomStats {
  const posAttr = geometry.attributes.position;
  const arr = posAttr.array as ArrayLike<number>;
  const cnt = posAttr.count;
  const idxAttr = geometry.index;
  const idx = idxAttr ? (idxAttr.array as ArrayLike<number>) : null;
  const n = idx ? idx.length : cnt;

  let minx = Infinity, miny = Infinity, minz = Infinity;
  let maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
  for (let v = 0; v < cnt; v++) {
    const x = arr[v * 3], y = arr[v * 3 + 1], z = arr[v * 3 + 2];
    if (x < minx) minx = x;
    if (y < miny) miny = y;
    if (z < minz) minz = z;
    if (x > maxx) maxx = x;
    if (y > maxy) maxy = y;
    if (z > maxz) maxz = z;
  }

  let sv = 0, cx = 0, cy = 0, cz = 0, area = 0;
  for (let t = 0; t < n; t += 3) {
    const ia = (idx ? idx[t] : t) * 3;
    const ib = (idx ? idx[t + 1] : t + 1) * 3;
    const ic = (idx ? idx[t + 2] : t + 2) * 3;
    const ax = arr[ia], ay = arr[ia + 1], az = arr[ia + 2];
    const bx = arr[ib], by = arr[ib + 1], bz = arr[ib + 2];
    const cxx = arr[ic], cyy = arr[ic + 1], czz = arr[ic + 2];
    const vv = (-cxx * by * az + bx * cyy * az + cxx * ay * bz - ax * cyy * bz - bx * ay * czz + ax * by * czz) / 6;
    sv += vv;
    cx += (vv * (ax + bx + cxx)) / 4;
    cy += (vv * (ay + by + cyy)) / 4;
    cz += (vv * (az + bz + czz)) / 4;
    const ux = bx - ax, uy = by - ay, uz = bz - az;
    const wx = cxx - ax, wy = cyy - ay, wz = czz - az;
    const px = uy * wz - uz * wy, py = uz * wx - ux * wz, pz = ux * wy - uy * wx;
    area += 0.5 * Math.sqrt(px * px + py * py + pz * pz);
  }

  const bcx = (minx + maxx) / 2, bcy = (miny + maxy) / 2, bcz = (minz + maxz) / 2;
  const comx = Math.abs(sv) > 1e-9 ? cx / sv : bcx;
  const comy = Math.abs(sv) > 1e-9 ? cy / sv : bcy;
  const comz = Math.abs(sv) > 1e-9 ? cz / sv : bcz;

  return {
    sx: maxx - minx,
    sy: maxy - miny,
    sz: maxz - minz,
    bcx, bcy, bcz,
    comx: comx - bcx,
    comy: comy - bcy,
    comz: comz - bcz,
    vol: Math.abs(sv),
    area,
    tris: Math.round(n / 3),
  };
}

export interface MatchResult {
  pct: number;
  sizeDiffPct: number;
  massDiffPct: number;
  comDistIn: number;
}

// Same weighting the shop's Job Matching uses: 0.40 size + 0.25 mass (volume
// proxy) + 0.35 center of mass.
export function matchPercent(a: GeomStats, b: GeomStats): MatchResult {
  const da = [a.sx, a.sy, a.sz].sort((x, y) => x - y);
  const db = [b.sx, b.sy, b.sz].sort((x, y) => x - y);
  let sd = 0;
  for (let i = 0; i < 3; i++) {
    const m = Math.max(da[i], db[i]) || 1;
    sd += Math.abs(da[i] - db[i]) / m;
  }
  sd /= 3;

  const massd = Math.abs(a.vol - b.vol) / (Math.max(a.vol, b.vol) || 1);

  const dx = a.comx - b.comx, dy = a.comy - b.comy, dz = a.comz - b.comz;
  const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
  const scale = (Math.max(a.sx, a.sy, a.sz) + Math.max(b.sx, b.sy, b.sz)) / 2 || 1;
  const cd = Math.min(1, dist / scale);

  const diff = 0.4 * sd + 0.25 * massd + 0.35 * cd;
  return {
    pct: Math.max(0, Math.min(100, (1 - diff) * 100)),
    sizeDiffPct: sd * 100,
    massDiffPct: massd * 100,
    comDistIn: dist,
  };
}

export function matchTone(pct: number): "success" | "warning" | "danger" {
  if (pct >= 92) return "success";
  if (pct >= 80) return "warning";
  return "danger";
}

// Rough material densities (lb / in^3) for a plain-language mass estimate.
// Volume is exact (computed from the mesh); mass is only ever an estimate,
// since STL files carry no material data. Falls back to tool steel.
const DENSITY_LOOKUP: { match: RegExp; density: number }[] = [
  { match: /alum/i, density: 0.098 },
  { match: /stainless/i, density: 0.29 },
  { match: /brass/i, density: 0.307 },
  { match: /copper/i, density: 0.323 },
  { match: /(tool steel|p20|h13|s7|a2|d2|steel)/i, density: 0.284 },
];
const DEFAULT_STEEL_DENSITY = 0.284;

export function densityFor(material?: string): number {
  if (material) {
    for (const { match, density } of DENSITY_LOOKUP) {
      if (match.test(material)) return density;
    }
  }
  return DEFAULT_STEEL_DENSITY;
}

export function estimateMassLb(volumeIn3: number, density: number): number {
  return volumeIn3 * density;
}

// Off-screen STL parse (no Canvas/WebGL context needed) -- used by the
// Comparison tab to batch-analyze every file in a job without rendering them.
const _offscreenLoader = new STLLoader();

export async function loadStlGeometry(url: string): Promise<BufferGeometry> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch ${url}: ${res.status} ${res.statusText}`);
  const buf = await res.arrayBuffer();
  return _offscreenLoader.parse(buf);
}
